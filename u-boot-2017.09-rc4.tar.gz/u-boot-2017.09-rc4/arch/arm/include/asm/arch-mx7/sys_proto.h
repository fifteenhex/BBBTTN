/*
 * Copyright (C) 2015 Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#include <asm/mach-imx/sys_proto.h>

void set_wdog_reset(struct wdog_regs *wdog);
