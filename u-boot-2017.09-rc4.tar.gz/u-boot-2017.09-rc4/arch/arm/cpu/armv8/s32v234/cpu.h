/*
 * (C) Copyright 2014-2016, Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

u32 cpu_mask(void);
int cpu_numcores(void);
